import time, binascii
import board, busio, digitalio

class MyRFID:
    def __init__(self, rx_pin=board.D9, baudrate=9600, reset_pin=board.D11,
                 active_high_reset=True, timeout=0.01, buf=1024):
        self.rx_pin = rx_pin
        self.baudrate = baudrate
        self.timeout = timeout
        self.buf = buf

        # Reset (your wiring: HIGH = reset)
        self.active_high_reset = active_high_reset
        self.rst = digitalio.DigitalInOut(reset_pin)
        self.rst.direction = digitalio.Direction.OUTPUT
        self.rst.value = not self.active_high_reset  # idle: not in reset

        self.uart = None
        self._uart_open(self.baudrate)

    # ---------- UART open/close ----------
    def _uart_open(self, baud):
        # Always deinit first if it exists
        if self.uart is not None:
            try:
                self.uart.deinit()
            except Exception:
                pass
            self.uart = None
            # tiny delay lets the pin free up
            time.sleep(0.01)

        # Now create fresh UART on the same RX pin
        self.uart = busio.UART(
            tx=None,
            rx=self.rx_pin,
            baudrate=baud,
            timeout=self.timeout,
            receiver_buffer_size=self.buf
        )
        self.baudrate = baud

    def close(self):
        if self.uart is not None:
            try:
                self.uart.deinit()
            except Exception:
                pass
            self.uart = None

    # ---------- reset ----------
    def reset_pulse(self, ms=60, settle_ms=300):
        self.rst.value = True if self.active_high_reset else False
        time.sleep(ms/1000)
        self.rst.value = False if self.active_high_reset else True
        time.sleep(settle_ms/1000)

    # ---------- sniff helpers ----------
    def _sniff_once(self, duration=2.5, line_mode=False):
        start = time.monotonic()
        collected = bytearray()
        lines = 0
        last = start
        while time.monotonic() - start < duration:
            if line_mode:
                line = self.uart.readline()
                if line:
                    lines += 1
                    collected.extend(line)
                    print("LINE:", line, "| HEX:", binascii.hexlify(line))
                else:
                    if time.monotonic() - last > 1.0:
                        print("(listening)")
                        last = time.monotonic()
            else:
                n = self.uart.in_waiting
                if n:
                    data = self.uart.read(n) or b""
                    if data:
                        collected.extend(data)
                        print("RX:", data, "| HEX:", binascii.hexlify(data))
                        last = time.monotonic()
                else:
                    if time.monotonic() - last > 1.0:
                        print("(listening)")
                        last = time.monotonic()
            time.sleep(0.01)
        return bytes(collected), lines

    def test(self, duration=8.0, use_lines=True, do_reset=True):
        if do_reset:
            print("Resetting module...")
            self.reset_pulse()

        print(f"Sniffing @ {self.baudrate} baud…")
        raw, _ = self._sniff_once(duration=duration/2, line_mode=False)
        lines_total = 0
        if use_lines:
            _, lines_total = self._sniff_once(duration=duration/2, line_mode=True)

        ok = bool(raw) or (lines_total > 0)
        if ok:
            print(f"[OK] Saw {len(raw)} raw byte(s) and {lines_total} line(s).")
        else:
            print("[!] No data at this baud.")
        return ok

    # ---------- clean baud sweep ----------
    def baud_sweep(self, rates=(9600, 19200, 38400, 57600, 115200), listen=3.0, reset_each=True):
        """
        For each baud:
          - deinit (free pin)
          - reopen UART at that baud
          - optional reset pulse
          - sniff raw then line mode
        Returns dict {baud: {"bytes": N, "lines": M}}
        """
        results = {}
        for b in rates:
            print(f"\n--- Testing {b} baud ---")
            self._uart_open(b)
            if reset_each:
                self.reset_pulse(ms=60, settle_ms=300)
            raw, _ = self._sniff_once(duration=listen, line_mode=False)
            _, lines = self._sniff_once(duration=max(1.5, listen/2), line_mode=True)
            results[b] = {"bytes": len(raw), "lines": lines}
            print(f"[{b}] bytes={len(raw)} lines={lines}")
        # restore original baud
        self._uart_open(self.baudrate)
        print("\nSweep summary:", results)
        return results

# ---- Example use ----
if __name__ == "__main__":
    rf = MyRFID(rx_pin=board.D9, baudrate=9600, reset_pin=board.D11, active_high_reset=True)
    # Keep a tag on the antenna during tests
    rf.baud_sweep(rates=(9600, 19200, 38400, 57600, 115200), listen=2.5, reset_each=True)
