import board
import busio
import sdcardio
import storage

spi = board.SPI()
cs = board.D10

separator = ','
mount_point = '/sd'

try:
    sdcard = sdcardio.SDCard(spi, cs)
    vfs = storage.VfsFat(sdcard)
    storage.mount(vfs, mount_point)
    print('SD card was mounted')
except OSError as e:
    print(e)
    print('SD card could not be mounted')