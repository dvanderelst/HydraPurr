import myADC
import myPixel
import myDigital
import myOLED
import myRTC
import time
import board

current_time = myRTC.data_time_str()
print('current date and time:', current_time)

water_level = myADC.myADC(0)
pixel = myPixel.myPixel(brightness = 0.1)
feeder = myDigital.myDigital(board.D9, 'output')
lick = myDigital.myDigital(board.D5, 'input', 'up')
oled = myOLED.myOLED()

while True:
    feeder.write(False)
    pixel.set_color('green')
    value = water_level.mean()
    lick_value = lick.read()
    
    print(value, lick_value)
    text_value = int(value * 1000)
    current_time = myRTC.time_str()
    
    oled.write(text_value, 5, 0, scale=2)
    oled.write(current_time, 5, 20, scale=1, clear=False)
    
    pixel.set_color('blue')
    feeder.write(True)
    time.sleep(0.5)



