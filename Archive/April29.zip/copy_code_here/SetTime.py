import myRTC

structure = {}
structure['year'] = 2024
structure['month'] = 12
structure['date'] = 9
    
structure['hours'] = 10
structure['minutes'] = 30
structure['seconds'] = 0
    
structure['weekday'] = 1

myRTC.set_time(structure)