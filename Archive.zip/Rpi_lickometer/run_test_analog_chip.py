from LickLibrary import myAnalog

analog = myAnalog.myAnalog()
values = analog.get_all_values()
print(values)