# Documentation

## Raspberry prerequisites

`pip3 install adafruit-blinka`

`pip3 install adafruit-circuitpython-mcp3xxx`

`pip3 install pillow`

`pip3 install adafruit-circuitpython-ssd1306`
