from LickLibrary import myOLED

oled = myOLED.myOLED()
oled.set_text(0, 'test line 1')
oled.set_text(1, 'test line 2')