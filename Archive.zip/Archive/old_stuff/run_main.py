from HydraPurr import HydraPurr
from LickCounter import LickCounter

hp = HydraPurr()
lc = LickCounter(clear_log=True)